import React from "react";

const PendingDocumentList = () => {
    return(
        <>Pending Document List</>
    )
}

export default PendingDocumentList;