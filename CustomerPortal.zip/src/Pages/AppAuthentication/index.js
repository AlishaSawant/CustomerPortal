import React from "react";

const AppAuthentication = (props) => {
    const {Component} = props;

    return(
        <>
            <Component />
        </>
    )
}

export default AppAuthentication;