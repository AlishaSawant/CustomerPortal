export const LOGO = require("../../Assets/Images/logo.png");
export const BG_IMG = require("../../Assets/Images/bg.jpg");

export const LOGIN_INIT = "LOGIN_INIT";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAILED = "LOGIN_FAILED";
