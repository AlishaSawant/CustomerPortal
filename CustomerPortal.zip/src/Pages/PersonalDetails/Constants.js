export const FIRST_NAME = require("../../Assets/Images/registered_name.png");
export const EMAIL = require("../../Assets/Images/email.png");
export const PHONE_NUMBER = require("../../Assets/Images/phone_number.png");
export const DOB = require("../../Assets/Images/dob.png");
export const PAN = require("../../Assets/Images/pan.png");
export const ID = require("../../Assets/Images/id.png");
export const LAST_NAME = require("../../Assets/Images/id-card.png");
export const PROFILE_PICTURE = require("../../Assets/Images/profile_picture.png");

