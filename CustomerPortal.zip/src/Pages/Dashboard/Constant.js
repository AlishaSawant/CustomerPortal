export const LOGO = require("../../Assets/Images/logo.png");
