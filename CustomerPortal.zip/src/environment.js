const PREPROD_API_URL = "http://172.17.89.180:8080/mdmService";

const preProd = {
  API_URL: `${PREPROD_API_URL}`,
  LOGIN: `${PREPROD_API_URL}/api/user/login/getLogin`,
};

const environment = preProd;

export default environment;
