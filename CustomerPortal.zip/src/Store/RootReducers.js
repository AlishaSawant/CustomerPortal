import { combineReducers } from "redux";
import { loginReducer } from "../Pages/Login/Reducers";

export default combineReducers({
    loginReducer, 
})


